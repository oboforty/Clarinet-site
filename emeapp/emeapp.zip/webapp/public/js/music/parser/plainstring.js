
function parse_notestring(notestr) {
  const notes = [];

  for(let i = 0; i <= len(notestr); i++) {
    if (tabs[i] == " ") continue;
    else if (tabs[i] == "-") continue; //@TODO: leave space?
    else {
      notes.push()
    }
  }

  return notes;
}